from django.apps import AppConfig


class PayrollAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'payroll_app'
